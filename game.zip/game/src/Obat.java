public class Obat {

}
