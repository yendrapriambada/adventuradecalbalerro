public class Item {
    private int level;
    private int hargaJual;
    private int hargaBeli;
    private int hargaPenaikanLevel;
    private String nama;
    private String jenisItem;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getHargaJual() {
        return hargaJual;
    }

    public void setHargaJual(int hargaJual) {
        this.hargaJual = hargaJual;
    }

    public int getHargaBeli() {
        return hargaBeli;
    }

    public void setHargaBeli(int hargaBeli) {
        this.hargaBeli = hargaBeli;
    }

    public int getHargaPenaikanLevel() {
        return hargaPenaikanLevel;
    }

    public void setHargaPenaikanLevel(int hargaPenaikanLevel) {
        this.hargaPenaikanLevel = hargaPenaikanLevel;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJenisItem() {
        return jenisItem;
    }

    public void setJenisItem(String jenisItem) {
        this.jenisItem = jenisItem;
    }
}
