public class NPC {

}
